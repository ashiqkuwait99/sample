package com.infosys.infymarket.product.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.infosys.infymarket.product.dto.ProductDTO;
import com.infosys.infymarket.product.dto.SubscribedProdDTO;
import com.infosys.infymarket.product.entity.Product;
import com.infosys.infymarket.product.service.ProductService;
import com.infosys.infymarket.product.service.SubscribedProdService;

@RestController
@CrossOrigin
public class ProductController {

	Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	ProductService productservice;
	
	@Autowired
	SubscribedProdService subproser;

	// Fetches 
	@RequestMapping(value = "/api/product/{productname}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getProductByName(@PathVariable String productname) {
		logger.info("productname request for product {}", productname);
		return productservice.getProductByName(productname);
	}
	@RequestMapping(value = "/api/products/{category}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getProductBycategory(@PathVariable String category) {
		logger.info("Category request for product {}",category);
		return productservice.getProductBycategory(category);
	}
	@GetMapping(value = "/api/products", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<ProductDTO> getAllProduct() {
		logger.info("Fetching all products");
		return productservice.getAllProduct();
	}
	@RequestMapping(value = "/api/verifyprod/{prodid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public ProductDTO getByProdid(@PathVariable String prodid) {
		logger.info("productname request for product {}", prodid);
		System.out.println("product");
		return productservice.getByProdid(prodid);
	}
	@RequestMapping(value = "/api/product/{prodid}", method = RequestMethod.PUT)
    public Product updateProductStock(@RequestBody Product product, @PathVariable String prodid) {
        return productservice.updateProductStock(product, prodid);
    }
	
	@RequestMapping(value = "/api/subs/{buyerid}", method = RequestMethod.GET, produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SubscribedProdDTO> getByBuyerid(@PathVariable String buyerid) {
		logger.info("productname request for product {}", buyerid);
		return subproser.getByBuyerid(buyerid);
	}
	@GetMapping(value = "/api/subscriptions", produces = MediaType.APPLICATION_JSON_VALUE)
	public List<SubscribedProdDTO> getAllSubProduct() {
		logger.info("Fetching all products");
		return subproser.getAllSubProduct();
	}
	@PostMapping(value = "/api/subscriptions/add", consumes = MediaType.APPLICATION_JSON_VALUE)
    public void saveSubscribedProd( @RequestBody SubscribedProdDTO subscribedProdDTO) {
        logger.info("Creation request for customer {} with data {}", subscribedProdDTO);
        subproser.saveSubscribedProd(subscribedProdDTO);
    }
//	@PostMapping(value = "/api/wishlist/add", consumes = MediaType.APPLICATION_JSON_VALUE)
//    public void saveWishlist( @RequestBody WishlistDTO wishlistDTO) {
//        logger.info("Creation request for customer {} with data {}", wishlistDTO);
//       productservice.saveWishlist(wishlistDTO);
//    }
//	CustomerDTO custDTO=custService.getCustomerProfile(phoneNo);
//    PlanDTO planDTO=template.getForObject("http://PLANMS"+"/plans/"+custDTO.getCurrentPlan().getPlanId(), PlanDTO.class);
//    custDTO.setCurrentPlan(planDTO);
}
