package com.infosys.infymarket.product.service;

import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import com.infosys.infymarket.product.dto.SubscribedProdDTO;
import com.infosys.infymarket.product.entity.SubscribedProd;
import com.infosys.infymarket.product.repository.SubscribedProdRepository;

@Service
public class SubscribedProdService {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	SubscribedProdRepository subscribedprodrepo;
	
	public List<SubscribedProdDTO> getByBuyerid(@PathVariable String buyerid) {

		logger.info("Productname request for product {}", buyerid);

		List<SubscribedProd> sub = subscribedprodrepo.findByBuyerid(buyerid);
		List<SubscribedProdDTO> subscribedprodDTO = new ArrayList<SubscribedProdDTO>();

		for (SubscribedProd subs : sub) {
			subscribedprodDTO.add(SubscribedProdDTO.valueOf(subs));
		}
		logger.info("Productname for product : {}", sub);

		return subscribedprodDTO;
	}
	public List<SubscribedProdDTO> getAllSubProduct() {

		List<SubscribedProd> subs = subscribedprodrepo.findAll();
		List<SubscribedProdDTO> subscribedprodDTOs = new ArrayList<>();

		for (SubscribedProd subpro : subs) {
			SubscribedProdDTO subscribedprodDTO = SubscribedProdDTO.valueOf(subpro);
			subscribedprodDTOs.add(subscribedprodDTO);
		}

		logger.info("Product Details : {}", subscribedprodDTOs);
		return subscribedprodDTOs;
	}
	public void saveSubscribedProd( SubscribedProdDTO subscribedprodDTO) {
        logger.info("Creation request for customer {} with data {}", subscribedprodDTO);
       // subscribedprodDTO.setBuyerid();
        SubscribedProd SubscribedProd = subscribedprodDTO.createSubscribedProd();
        subscribedprodrepo.save(SubscribedProd);
    }
	
}
