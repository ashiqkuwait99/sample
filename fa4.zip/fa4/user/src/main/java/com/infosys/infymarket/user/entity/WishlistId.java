package com.infosys.infymarket.user.entity;

import java.io.Serializable;

public class WishlistId implements Serializable{


	String buyerid;
	String prodid;
	public String getBuyerid() {
		return buyerid;
	}
	public void setBuyerid(String buyerid) {
		this.buyerid = buyerid;
	}
	public String getProdid() {
		return prodid;
	}
	public void setProdid(String prodid) {
		this.prodid = prodid;
	}
	public WishlistId(String buyerid, String prodid) {
		super();
		this.buyerid = buyerid;
		this.prodid = prodid;
	}
	public WishlistId() {
		
	}
 
}
